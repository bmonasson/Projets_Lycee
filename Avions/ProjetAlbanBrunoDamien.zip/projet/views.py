import sqlite3
from flask import Flask
from flask import render_template, request, redirect, session, url_for, g
import sys
import json
app = Flask(__name__)


app = Flask(__name__)

DATABASE = "data/projet.db"
l_id = []


# Gestion de la base de données (copier-coller de la doc de FLASK)
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

def query_db(query, args=(), one=False):
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv

def change_db(query,args=()):
    cur = get_db().execute(query, args)
    get_db().commit()
    cur.close()

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()


# Routage des URL et traitement
@app.route('/')
def index():
    villes = query_db("SELECT DISTINCT ville FROM aeroports ORDER BY ville;")
    date = query_db("SELECT DISTINCT day FROM vols ORDER BY day;")

    return render_template("index.html",ville=villes,date=date)

@app.route('/index.html')
def revenir():
    return index()

@app.route('/select_multicritere', methods=['POST', 'GET'])
def select_multricritere():
    result = request.form
    print("result   ", list(result.keys()))
    vdep = "%" + result['ville de départ'] + "%"
    varr = "%" + result["ville d'arrivée"] + "%" 
    date = "%" + result['date'] + "%"
    res = query_db("SELECT * FROM vols \
                    JOIN aeroports ON vols.origine = aeroports.ICAO_code \
                    WHERE vols.origine IN (SELECT ICAO_code FROM aeroports WHERE aeroports.ville like ?) \
                    AND vols.destination IN (SELECT ICAO_code FROM aeroports WHERE aeroports.ville like ?) \
                    AND vols.day like ? \
                    ORDER BY vols.day", [vdep, varr, date], one = False)

    dico = creation_dictionnaire(res)
    comp = compagnie(res)
    print(comp)

    return render_template("resultat.html", resultat=res, dictionnaire = dico, compagnie = comp)



@app.route('/select_idvol', methods=['POST'])
def select_idvol():
    global l_id

    result = request.form
    idvol = result['numero de vol']
    l_id.append(idvol)
    return ouvre_vol(idvol)




def ouvre_vol(idvol):
    if not idvol :
        return render_template("index.html")
    print("ouvre vol n°", idvol)
    res = query_db("SELECT * FROM vols \
                    WHERE Id_vol =  ?", [idvol], one = False)

    avion = query_db("SELECT * FROM avion \
                    WHERE Id_avion = ? ", [res[0]["Id_avion"]], one = False)
    
    pilote = query_db("SELECT * FROM pilotes \
                    WHERE Id_pilote = ? ", [res[0]["Id_pilote"]], one = False)
     
    avionmodele = avion[0]["modele"].split(" ")[1:] #On garde tout sauf le premier mot (Boeing ou Airbus)
    print("avionmodele = ", avionmodele)
    modeleavion = ""
    for el in avionmodele:
        modeleavion += el + " "
    modeleavion = "%" + modeleavion[:-1] + "%"

    print(modeleavion)

    modele = query_db("SELECT * FROM modele \
                        WHERE Modèle like ?", [modeleavion], one = False)

    print("modele = ", modele)


    dico = creation_dictionnaire(res)

    return render_template("vol.html", resultat=res[0], dictionnaire = dico, avion = avion[0], pilote = pilote[0], modele = modele[0])


@app.route('/info_vol/<string:volInfo>', methods = ['GET', 'POST'])
def info_vol(volInfo):
    global l_id
    volInfo = json.loads(volInfo)
    l_id.append(int(volInfo))

    return ouvre_vol(int(volInfo))

def creation_dictionnaire(res):
    dico = {}
    for ligne in res :
        dep = ligne["origine"]
        if dep not in dico :
            nom_dep = query_db("SELECT nom FROM aeroports \
                                WHERE ICAO_code like ?", [dep], one = False)
            dico[dep] = nom_dep[0]["nom"]
            print(dep, dico[dep])

        arr = ligne["destination"]
        if arr not in dico :
            nom_arr = query_db("SELECT nom FROM aeroports \
                                WHERE ICAO_code like ?", [arr], one = False)
            dico[arr] = nom_arr[0]["nom"]
    
    return dico

def compagnie(res):
    compagnies = {}

    for ligne in res :
        id_avion = ligne["Id_avion"]
        
        avion = query_db("SELECT * FROM avion \
                    WHERE Id_avion = ? ", [id_avion], one = False)
        
        compagnies[id_avion] = avion[0]["compagnie"]
    
    return compagnies

@app.route('/select_reservation', methods=['GET','POST'])
def reservation():
    global l_id
    
    result = request.form
    nom_client = result['nom_client']
    nb_personnes = result['nb_personnes']
    
    resid = query_db("SELECT * FROM vols where Id_vol = ?", [l_id[-1]])
    id_avion = None
    
    for el in resid:
        id_avion = el
    
    ajout = change_db("INSERT INTO reservations (Id_vol, Id_avion, nom_client, nb_personnes) VALUES (?, ? , ?,  ?)\
            ", [l_id[-1], id_avion['id_avion'], nom_client, nb_personnes])
    res = query_db("SELECT * FROM reservations WHERE Id_vol = ?", [l_id[-1]], one = False)
    

   
    return render_template("special.html", resultat=res)



    




app.run(debug=True)
