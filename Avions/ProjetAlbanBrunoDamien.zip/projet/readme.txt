Pour ouvrir le site il faut ouvrir views.py dans un éditeur python et lancer le programme. Ensuite il faut ouvrir la page localhost:5000 dans un navigateur. 

Pour faire une recherche il faut taper le nom d'une ville de départ, une ville d'arrivée et sélectionner une date ou indiquer le numéro du vol. NB : les champs ne sont pas obligatoires et les laisser vide équivaut à ne pas prendre en compte ce paramètre lors de la recherche du vol (par exemple si vous ne pas remplissez pas la ville d'arrivée, uniquement la ville de départ et la date seront pris en compte lors de la recherche...).

NB : Il est important de garder la même arborescence sinon il risque d'y avoir des erreurs au moment de chercher des fichiers (par exemple les images).


Le fichier python bd est un fichier Jupyter notebook qui regroupe toutes les fonctions utilisées lors de la création de la base de données. Toutefois il n'est pas nécessaire de le lancer car la base de données est déjà complète.

